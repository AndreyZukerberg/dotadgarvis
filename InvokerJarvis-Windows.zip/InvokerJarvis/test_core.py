import copy
import unittest
from core import DEFAULTS, SPELLS, execute, recognize, sequence, validate


class Recorder:
    def __init__(self):
        self.events = []

    def down(self, key):
        self.events.append(('down', key))

    def up(self, key):
        self.events.append(('up', key))


class Tests(unittest.TestCase):
    def setUp(self):
        self.config = copy.deepcopy(DEFAULTS)

    def test_all_ten_recipes_and_aliases(self):
        expected = {'Cold Snap': 'qqq', 'Ghost Walk': 'qqw', 'Ice Wall': 'qqe',
                    'EMP': 'www', 'Tornado': 'qww', 'Alacrity': 'wwe',
                    'Sun Strike': 'eee', 'Forge Spirit': 'qee',
                    'Chaos Meteor': 'wee', 'Deafening Blast': 'qwe'}
        self.assertEqual({s.name: s.orbs for s in SPELLS}, expected)
        for spell in SPELLS:
            for alias in spell.aliases:
                self.assertEqual(recognize(alias), spell)
                self.assertEqual(recognize('Джарвис, ' + alias, True), spell)
                self.assertIsNone(recognize(alias, True))
            recorder = Recorder()
            self.assertTrue(execute(spell, self.config, recorder, lambda: True, lambda _: None))
            expected_keys = list(expected[spell.name] + 'rd')
            self.assertEqual(recorder.events, [(action, key) for key in expected_keys for action in ('down', 'up')])

    def test_no_substring_or_multiple_spell_commands(self):
        for text in ('не используй метеор', 'метеор торнадо', 'шум', '', '[unk] метеор'):
            self.assertIsNone(recognize(text))

    def test_rebinding(self):
        self.config['keys'] = dict(q='1', w='2', e='3', invoke='4', cast='5')
        validate(self.config)
        self.assertEqual(sequence(SPELLS[4], self.config), ['1', '2', '2', '4', '5'])

    def test_cancellation_releases_held_key(self):
        recorder = Recorder()
        self.assertFalse(execute(SPELLS[0], self.config, recorder, lambda: not recorder.events, lambda _: None))
        self.assertEqual(recorder.events, [('down', 'q'), ('up', 'q')])

    def test_focus_loss_after_invoke_never_casts(self):
        recorder = Recorder()
        self.assertFalse(execute(SPELLS[0], self.config, recorder, lambda: ('up', 'r') not in recorder.events, lambda _: None))
        self.assertNotIn(('down', 'd'), recorder.events)
        self.assertEqual(recorder.events[-1], ('up', 'r'))

    def test_initially_disallowed(self):
        recorder = Recorder()
        self.assertFalse(execute(SPELLS[0], self.config, recorder, lambda: False))
        self.assertEqual(recorder.events, [])

    def test_errors_release_key(self):
        recorder = Recorder()
        def failure(_):
            raise RuntimeError('simulated error')
        with self.assertRaises(RuntimeError):
            execute(SPELLS[0], self.config, recorder, lambda: True, failure)
        self.assertEqual(recorder.events[-1], ('up', 'q'))

    def test_invalid_configuration(self):
        for value in (-1, 10000, '65'):
            self.config['key_gap_ms'] = value
            with self.assertRaises(ValueError):
                validate(self.config)
        self.config = copy.deepcopy(DEFAULTS)
        self.config['keys']['cast'] = 'q'
        with self.assertRaises(ValueError):
            validate(self.config)


if __name__ == '__main__':
    unittest.main()
