import copy
import http.client
import json
from pathlib import Path
import tempfile
import unittest

from core import DEFAULTS, SPELLS, execute
from gsi import State, CastGuard, Server, load_token, install_config
from test_core import Recorder


def payload():
    return {
        'provider': {'appid': 570, 'timestamp': 1000},
        'map': {'game_state': 'DOTA_GAMERULES_STATE_GAME_IN_PROGRESS', 'paused': False},
        'player': {'activity': 'playing'},
        'hero': {'name': 'npc_dota_hero_invoker', 'alive': True},
        'abilities': {
            'ability0': {'name': 'invoker_quas', 'level': 1},
            'ability1': {'name': 'invoker_wex', 'level': 1},
            'ability2': {'name': 'invoker_exort', 'level': 1},
            'ability3': {'name': 'invoker_cold_snap', 'cooldown': 0, 'can_cast': True},
            'ability4': {'name': 'invoker_chaos_meteor', 'cooldown': 0, 'can_cast': True},
            'ability5': {'name': 'invoker_invoke', 'cooldown': 0, 'can_cast': True},
        },
    }


class GuardTests(unittest.TestCase):
    def setUp(self):
        self.now = 0.0
        self.state = State(lambda: self.now, lambda: 1000)
        self.data = payload()
        self.state.update(self.data)
        self.spell = SPELLS[4]  # Tornado, initially absent in the first slot.
        self.recorder = Recorder()
        self.guard = CastGuard(self.state, self.spell, lambda: self.now, self.advance)
        self.config = copy.deepcopy(DEFAULTS)

    def advance(self, duration):
        self.now += duration

    def run_command(self, sleep=None):
        return execute(self.spell, self.config, self.recorder, lambda: True,
                       sleep or self.advance, self.guard)

    def test_invoke_cooldown_sends_nothing(self):
        self.data['abilities']['ability5']['cooldown'] = 2
        self.state.update(self.data)
        self.assertFalse(self.run_command())
        self.assertEqual(self.recorder.events, [])
        self.assertIn('перезарядка 2', self.guard.error)

    def test_unknown_or_unavailable_invoke_sends_nothing(self):
        for change in ({'can_cast': False}, {'can_cast': None}, {'cooldown': None},
                       {'cooldown': -1}, {'cooldown': float('nan')}, {'cooldown': True}):
            with self.subTest(change=change):
                self.data = payload()
                self.data['abilities']['ability5'].update(change)
                self.state.update(self.data)
                self.assertFalse(self.run_command())
                self.assertEqual(self.recorder.events, [])

    def test_missing_stale_and_old_source_data(self):
        for data in ({}, {**payload(), 'provider': {'appid': 570, 'timestamp': 900}}):
            self.state.update(data)
            self.assertFalse(self.run_command())
            self.assertEqual(self.recorder.events, [])
        self.state.update(payload())
        self.now = 2
        self.assertFalse(self.run_command())
        self.assertEqual(self.recorder.events, [])

    def test_bad_hero_spectator_and_paused_match(self):
        changes = [('hero', 'name', 'npc_dota_hero_axe'), ('hero', 'alive', False),
                   ('hero', 'stunned', True), ('player', 'activity', 'spectating'),
                   ('map', 'paused', True), ('map', 'game_state', 'DOTA_GAMERULES_STATE_POST_GAME')]
        for section, field, value in changes:
            self.data = payload()
            self.data[section][field] = value
            self.state.update(self.data)
            self.assertFalse(self.run_command())
            self.assertEqual(self.recorder.events, [])

    def test_unlearned_orb(self):
        self.data['abilities']['ability1']['level'] = 0
        self.state.update(self.data)
        self.assertFalse(self.run_command())
        self.assertEqual(self.recorder.events, [])

    def test_cooldown_changed_during_orbs_blocks_r_and_d(self):
        def sleep(duration):
            self.advance(duration)
            if ('up', 'w') in self.recorder.events:
                self.data['abilities']['ability5']['cooldown'] = 5
                self.state.update(self.data)
        self.assertFalse(self.run_command(sleep))
        self.assertNotIn(('down', 'r'), self.recorder.events)
        self.assertNotIn(('down', 'd'), self.recorder.events)

    def test_no_post_invoke_update_never_casts_even_if_already_correct(self):
        self.data['abilities']['ability3']['name'] = 'invoker_tornado'
        self.state.update(self.data)
        self.assertFalse(self.run_command())
        self.assertIn(('down', 'r'), self.recorder.events)
        self.assertNotIn(('down', 'd'), self.recorder.events)

    def confirmed_sleep(self, duration):
        self.advance(duration)
        if ('up', 'r') in self.recorder.events:
            self.state.update(self.data)

    def test_wrong_spell_fresh_update_never_casts(self):
        self.guard.sleep = self.confirmed_sleep
        self.assertFalse(self.run_command(self.confirmed_sleep))
        self.assertNotIn(('down', 'd'), self.recorder.events)

    def test_confirmation_for_all_ten_spells(self):
        for spell in SPELLS:
            with self.subTest(spell=spell.name):
                self.now = 0
                self.recorder = Recorder()
                self.spell = spell
                self.data = payload()
                self.state.update(self.data)
                def confirm(duration):
                    self.advance(duration)
                    if ('up', 'r') in self.recorder.events:
                        self.data['abilities']['ability3']['name'] = 'invoker_' + spell.name.lower().replace(' ', '_')
                        self.data['abilities']['ability5']['cooldown'] = 4
                        self.state.update(self.data)
                self.guard = CastGuard(self.state, spell, lambda: self.now, confirm)
                self.assertTrue(self.run_command(confirm))
                self.assertEqual(self.recorder.events[-2:], [('down', 'd'), ('up', 'd')])

    def test_correct_spell_cooldown_or_no_mana_never_casts(self):
        for field, value in (('cooldown', 4), ('can_cast', False)):
            self.setUp()
            self.data['abilities']['ability3'].update(name='invoker_tornado')
            self.data['abilities']['ability3'][field] = value
            self.guard.sleep = self.confirmed_sleep
            self.assertFalse(self.run_command(self.confirmed_sleep))
            self.assertNotIn(('down', 'd'), self.recorder.events)

    def test_pause_cancels_confirmation_wait(self):
        self.guard.after_key(3)
        self.assertFalse(self.guard.before_key(4, lambda: False))
        self.assertEqual(self.now, 0)

    def test_removed_fields_are_not_merged(self):
        self.state.update({'provider': payload()['provider']})
        self.assertTrue(self.state.invoke_error())


class SetupTests(unittest.TestCase):
    def test_install_and_stable_token(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            token = load_token(root)
            self.assertEqual(token, load_token(root))
            with self.assertRaises(ValueError):
                install_config(root, token)
            (root / 'game/dota/cfg').mkdir(parents=True)
            (root / 'game/bin/win64').mkdir(parents=True)
            (root / 'game/bin/win64/dota2.exe').touch()
            target = install_config(root, token)
            self.assertIn(token, target.read_text())
            self.assertIn('127.0.0.1:37219', target.read_text())


class HTTPTests(unittest.TestCase):
    def test_local_post_auth_and_invalid_json(self):
        state = State(lambda: 0, lambda: 1000)
        server = Server(state, 'test-token', port=0)
        port = server.http.server_port
        try:
            for body, expected in (({**payload(), 'auth': {'token': 'wrong'}}, 403),
                                   ([1, 2], 400),
                                   ({**payload(), 'auth': {'token': 'test-token'}}, 200)):
                connection = http.client.HTTPConnection('127.0.0.1', port, timeout=2)
                connection.request('POST', '/', json.dumps(body), {'Content-Type': 'application/json'})
                response = connection.getresponse()
                self.assertEqual(response.status, expected)
                response.read()
                connection.close()
            self.assertEqual(state.snapshot()[2], 1)
            self.assertEqual(state.invoke_error(), '')
        finally:
            server.close()


if __name__ == '__main__':
    unittest.main()
