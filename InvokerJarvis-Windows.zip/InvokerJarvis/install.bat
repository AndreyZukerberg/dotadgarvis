@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto no_python
py -3.11 -c "import sys; assert sys.maxsize > 2**32" >nul 2>nul
if errorlevel 1 goto no_python
if not exist ".venv\Scripts\python.exe" py -3.11 -m venv .venv
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" download_model.py
if errorlevel 1 goto failed
echo Installation complete. Run start.bat.
pause
exit /b 0
:no_python
echo Install Python 3.11 64-bit from python.org with the Python Launcher.
echo Then run install.bat again. See README.md.
pause
exit /b 1
:failed
echo Installation failed. Read the error above and retry install.bat.
pause
exit /b 1
