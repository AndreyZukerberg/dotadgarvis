"""Spell vocabulary and cancellable execution; no OS/audio dependencies."""
from dataclasses import dataclass
import re
import time


@dataclass(frozen=True)
class Spell:
    name: str
    orbs: str
    aliases: tuple[str, ...]


SPELLS = (
    Spell('Cold Snap', 'qqq', ('колд снап', 'холод', 'заморозка')),
    Spell('Ghost Walk', 'qqw', ('гост волк', 'гост вок', 'инвиз', 'невидимость')),
    Spell('Ice Wall', 'qqe', ('айс волл', 'айс вол', 'стенка', 'ледяная стена')),
    Spell('EMP', 'www', ('эмп', 'эм пэ', 'е эм пи', 'импульс')),
    Spell('Tornado', 'qww', ('торнадо', 'смерч')),
    Spell('Alacrity', 'wwe', ('алакрити', 'алакрити баф', 'ускорение')),
    Spell('Sun Strike', 'eee', ('сан страйк', 'санстрайк', 'солнечный удар')),
    Spell('Forge Spirit', 'qee', ('фордж спирит', 'форжи', 'духи', 'дух')),
    Spell('Chaos Meteor', 'wee', ('хаос метеор', 'метеор', 'метеорит')),
    Spell('Deafening Blast', 'qwe', ('дефенинг бласт', 'бласт', 'волна')),
)
DEFAULTS = {
    'keys': {'q': 'q', 'w': 'w', 'e': 'e', 'invoke': 'r', 'cast': 'd'},
    'key_hold_ms': 35, 'key_gap_ms': 65, 'invoke_wait_ms': 250,
    'device': None, 'dry_run': False, 'require_jarvis': False,
    'minimum_confidence': 0.65,
}


def normalize(text):
    return ' '.join(re.sub(r'[^a-zа-яё0-9\s]', ' ', text.lower()).replace('ё', 'е').split())


def vocabulary(require_jarvis=False):
    aliases = [a for spell in SPELLS for a in spell.aliases]
    return (['джарвис ' + a for a in aliases] if require_jarvis
            else aliases + ['джарвис ' + a for a in aliases]) + ['[unk]']


def recognize(text, require_jarvis=False):
    text = normalize(text)
    prefix = 'джарвис '
    if text.startswith(prefix):
        text = text[len(prefix):]
    elif require_jarvis:
        return None
    # Full-phrase match prevents firing on a substring or a two-spell sentence.
    return next((s for s in SPELLS if text in (*s.aliases, normalize(s.name))), None)


def validate(config):
    keys = config['keys']
    for role in DEFAULTS['keys']:
        if not re.fullmatch('[a-z0-9]', keys.get(role, '')):
            raise ValueError('Клавиши: одна латинская буква или цифра без модификаторов.')
    if len(set(keys.values())) != len(keys):
        raise ValueError('Клавиши сфер, Invoke и применения должны отличаться.')
    for name, low, high in (('key_hold_ms', 15, 200), ('key_gap_ms', 20, 500),
                             ('invoke_wait_ms', 50, 2000)):
        value = config[name]
        if type(value) is not int or not low <= value <= high:
            raise ValueError(f'{name}: допустимо {low}–{high} мс.')
    if not 0 <= config['minimum_confidence'] <= 1:
        raise ValueError('minimum_confidence: допустимо 0–1.')


def sequence(spell, config):
    return [config['keys'][orb] for orb in spell.orbs] + [config['keys']['invoke'], config['keys']['cast']]


def execute(spell, config, keyboard, allowed, sleep=time.sleep, guard=None):
    """Check cancellation/focus before every key; release keys even on failure."""
    def wait(milliseconds):
        remaining = milliseconds / 1000
        while remaining > 0:
            if not allowed():
                return False
            duration = min(0.01, remaining)
            sleep(duration)
            remaining -= duration
        return allowed()

    for i, key in enumerate(sequence(spell, config)):
        if not allowed():
            return False
        if guard is not None and not guard.before_key(i, allowed):
            return False
        if not allowed():
            return False
        try:
            keyboard.down(key)
            completed = wait(config['key_hold_ms'])
        finally:
            keyboard.up(key)
        if not completed:
            return False
        if guard is not None:
            guard.after_key(i)
        if i < 4 and not wait(config['invoke_wait_ms'] if i == 3 else config['key_gap_ms']):
            return False
    return True
