"""Local Dota GSI receiver and fail-closed Invoke/cast checks."""
import copy
import hmac
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import math
from pathlib import Path
import secrets
import threading
import time

PORT = 37219
MAX_AGE = 1.5
CONFIRM_TIMEOUT = 1.5


def number(value):
    return type(value) in (int, float) and math.isfinite(value)


def load_token(root):
    path = Path(root) / 'gsi_token.txt'
    if not path.exists():
        try:
            with path.open('x', encoding='ascii') as output:
                output.write(secrets.token_hex(32))
        except FileExistsError:
            pass
    token = path.read_text(encoding='ascii').strip()
    if len(token) != 64 or any(c not in '0123456789abcdef' for c in token):
        raise ValueError('Некорректный gsi_token.txt. Закройте помощник, удалите файл и подключите Dota заново.')
    return token


def install_config(dota_root, token):
    root = Path(dota_root)
    cfg = root / 'game' / 'dota' / 'cfg'
    if not cfg.is_dir() or not (root / 'game' / 'bin' / 'win64' / 'dota2.exe').is_file():
        raise ValueError('Выберите папку «dota 2 beta»: внутри должны быть game/dota/cfg и game/bin/win64/dota2.exe.')
    folder = cfg / 'gamestate_integration'
    folder.mkdir(exist_ok=True)
    target = folder / 'gamestate_integration_invoker_jarvis.cfg'
    text = f'''"Invoker Jarvis"
{{
    "uri" "http://127.0.0.1:{PORT}/"
    "timeout" "1.0"
    "buffer" "0.05"
    "throttle" "0.1"
    "heartbeat" "0.25"
    "data"
    {{
        "provider" "1"
        "map" "1"
        "player" "1"
        "hero" "1"
        "abilities" "1"
    }}
    "auth"
    {{
        "token" "{token}"
    }}
}}
'''
    temporary = target.with_suffix('.tmp')
    temporary.write_text(text, encoding='ascii')
    temporary.replace(target)
    return target


class State:
    def __init__(self, clock=time.monotonic, wall_clock=time.time):
        self.clock, self.wall_clock = clock, wall_clock
        self.lock = threading.Lock()
        self.data = {}
        self.received = float('-inf')
        self.revision = 0

    def update(self, payload):
        # GSI posts full snapshots. Never retain missing fields from older data.
        with self.lock:
            self.data = copy.deepcopy(payload)
            self.received = self.clock()
            self.revision += 1

    def snapshot(self):
        with self.lock:
            return copy.deepcopy(self.data), self.received, self.revision

    def checked(self):
        data, received, revision = self.snapshot()
        if self.clock() - received > MAX_AGE:
            return data, revision, 'Нет свежих данных Dota: подключите GSI.'
        for section in ('provider', 'map', 'player', 'hero', 'abilities'):
            if not isinstance(data.get(section), dict):
                return data, revision, f'GSI: нет раздела {section}.'
        provider = data['provider']
        stamp = provider.get('timestamp')
        if provider.get('appid') != 570 or not number(stamp) or abs(self.wall_clock() - stamp) > 5:
            return data, revision, 'GSI: неверный источник или устаревшее время пакета.'
        if data['player'].get('activity') != 'playing':
            return data, revision, 'GSI: игрок не в игре.'
        if data['map'].get('game_state') not in ('DOTA_GAMERULES_STATE_PRE_GAME', 'DOTA_GAMERULES_STATE_GAME_IN_PROGRESS'):
            return data, revision, 'GSI: матч ещё не начался или уже завершён.'
        if data['map'].get('paused') is True:
            return data, revision, 'Матч на паузе.'
        hero = data['hero']
        if hero.get('name') != 'npc_dota_hero_invoker' or hero.get('alive') is not True:
            return data, revision, 'Нужен живой Инвокер вашего игрока.'
        for flag in ('stunned', 'silenced', 'hexed'):
            if hero.get(flag) is True:
                return data, revision, 'Инвокер сейчас не может применять способности.'
        return data, revision, ''

    @staticmethod
    def ability_error(ability, label):
        if not isinstance(ability, dict):
            return f'GSI: нет данных о {label}.'
        cooldown = ability.get('cooldown')
        if not number(cooldown) or cooldown < 0:
            return f'GSI: неизвестна перезарядка {label}.'
        if cooldown > 0:
            return f'{label}: перезарядка {cooldown:g} с.'
        if ability.get('can_cast') is not True:
            return f'{label} сейчас недоступен (can_cast=false или нет данных).'
        return ''

    def invoke_error(self, spell=None):
        data, _, error = self.checked()
        if error:
            return error
        abilities = data['abilities']
        invoke = next((a for a in abilities.values() if isinstance(a, dict) and a.get('name') == 'invoker_invoke'), None)
        error = self.ability_error(invoke, 'Invoke')
        if error or spell is None:
            return error
        for orb in set(spell.orbs):
            name = {'q': 'invoker_quas', 'w': 'invoker_wex', 'e': 'invoker_exort'}[orb]
            ability = next((a for a in abilities.values() if isinstance(a, dict) and a.get('name') == name), {})
            if not number(ability.get('level')) or ability['level'] <= 0:
                return f'Не изучена нужная сфера: {name}.'
        return ''

    def cast_error(self, spell, after_revision):
        data, revision, error = self.checked()
        if error:
            return error
        if revision <= after_revision:
            return 'Нет нового подтверждения от Dota после Invoke.'
        # Standard Dota ability layout: ability0/1/2=orbs, ability3=first spell.
        # Fail closed if a patch changes the layout instead of guessing a slot.
        ability = data['abilities'].get('ability3')
        expected = 'invoker_' + spell.name.lower().replace(' ', '_')
        if not isinstance(ability, dict) or ability.get('name') != expected:
            return f'Dota не подтвердила {spell.name} в первом слоте; D отменено.'
        return self.ability_error(ability, spell.name)


class CastGuard:
    def __init__(self, state, spell, clock=time.monotonic, sleep=time.sleep):
        self.state, self.spell = state, spell
        self.clock, self.sleep = clock, sleep
        self.after_revision = None
        self.error = ''

    def before_key(self, index, allowed):
        if index < 4:
            self.error = self.state.invoke_error(self.spell)
            return not self.error
        if self.after_revision is None:
            self.error = 'Invoke не был отправлен; D отменено.'
            return False
        deadline = self.clock() + CONFIRM_TIMEOUT
        while allowed():
            self.error = self.state.cast_error(self.spell, self.after_revision)
            if not self.error:
                return True
            if self.clock() >= deadline:
                return False
            self.sleep(0.02)
        self.error = 'Команда отменена: пауза, модификатор или смена окна.'
        return False

    def after_key(self, index):
        if index == 3:
            self.after_revision = self.state.snapshot()[2]


class Server:
    def __init__(self, state, token, port=PORT):
        class Handler(BaseHTTPRequestHandler):
            def setup(self):
                super().setup()
                self.connection.settimeout(1)

            def log_message(self, *args):
                pass

            def do_POST(self):
                try:
                    length = int(self.headers.get('Content-Length', '0'))
                    if self.path != '/' or not 0 < length <= 262144:
                        self.send_error(400)
                        return
                    raw = self.rfile.read(length)
                    if len(raw) != length:
                        self.send_error(400)
                        return
                    def reject_constant(value):
                        raise ValueError('Non-finite number')
                    payload = json.loads(raw, parse_constant=reject_constant)
                    if not isinstance(payload, dict):
                        self.send_error(400)
                        return
                    auth = payload.get('auth')
                    supplied = auth.get('token') if isinstance(auth, dict) else None
                    if not isinstance(supplied, str) or not hmac.compare_digest(supplied.encode('utf-8'), token.encode('ascii')):
                        self.send_error(403)
                        return
                    state.update(payload)
                    self.send_response(200)
                    self.send_header('Content-Length', '0')
                    self.end_headers()
                except (ValueError, UnicodeError, TimeoutError, OSError):
                    self.close_connection = True
        self.http = HTTPServer(('127.0.0.1', port), Handler)
        self.thread = threading.Thread(target=self.http.serve_forever, kwargs={'poll_interval': 0.1}, daemon=True)
        self.thread.start()

    def close(self):
        self.http.shutdown()
        self.http.server_close()
        self.thread.join(timeout=2)
