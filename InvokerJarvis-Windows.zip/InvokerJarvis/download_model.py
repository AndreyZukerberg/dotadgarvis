"""Download the official small Russian Vosk model once, then work offline."""
from pathlib import Path
import shutil
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
NAME = 'vosk-model-small-ru-0.22'
URL = f'https://alphacephei.com/vosk/models/{NAME}.zip'


def main():
    if (ROOT / 'model' / 'am' / 'final.mdl').is_file():
        print('Russian model is already installed.')
        return
    print('Downloading Russian voice model (~45 MB) from alphacephei.com...', flush=True)
    with tempfile.TemporaryDirectory(dir=ROOT) as temporary:
        folder = Path(temporary)
        archive = folder / 'model.zip'
        with urllib.request.urlopen(URL, timeout=60) as response, archive.open('wb') as output:
            shutil.copyfileobj(response, output)
        with zipfile.ZipFile(archive) as zipped:
            for entry in zipped.infolist():
                destination = (folder / entry.filename).resolve()
                if not destination.is_relative_to(folder.resolve()):
                    raise RuntimeError('Unexpected model archive path.')
            zipped.extractall(folder)
        source = folder / NAME
        if not (source / 'am' / 'final.mdl').is_file():
            raise RuntimeError('Downloaded archive does not contain a complete model.')
        if (ROOT / 'model').exists():
            raise RuntimeError('Incomplete model folder exists. Rename it and run install.bat again.')
        shutil.move(str(source), str(ROOT / 'model'))
    print('Model installed. Run start.bat.')


if __name__ == '__main__':
    main()
