"""Offline Russian voice assistant for Invoker, Windows 10/11."""
import copy
import json
from pathlib import Path
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from core import DEFAULTS, SPELLS, execute, recognize, sequence, validate, vocabulary
from windows_input import WindowsInput
from gsi import State, Server, CastGuard, load_token, install_config

ROOT = Path(__file__).resolve().parent


class App:
    def __init__(self, window):
        self.window = window
        self.keyboard = WindowsInput()
        self.config = copy.deepcopy(DEFAULTS)
        self.events = queue.Queue()
        self.audio = queue.Queue(maxsize=12)
        self.shutdown = threading.Event()
        self.lock = threading.Lock()
        self.armed = False
        self.ready = False
        self.epoch = 0
        self.listening = False
        self.discard_before = time.monotonic()
        self.previous_hotkeys = {}
        self.worker = None
        self.gsi = State()
        self.gsi_server = None
        self.gsi_token = None
        try:
            if (ROOT / 'config.json').exists():
                loaded = json.loads((ROOT / 'config.json').read_text(encoding='utf-8'))
                self.config.update(loaded)
                validate(self.config)
        except (ValueError, TypeError, KeyError) as error:
            self.config = copy.deepcopy(DEFAULTS)
            messagebox.showwarning('Настройки сброшены', str(error))

        window.title('JARVIS · Invoker')
        window.geometry('850x840')
        window.minsize(790, 740)
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TFrame', background='#141c2c')
        style.configure('TLabel', background='#141c2c', foreground='#e5eaf3', font=('Segoe UI', 10))
        style.configure('TCheckbutton', background='#141c2c', foreground='#e5eaf3')
        style.configure('TButton', font=('Segoe UI', 10), padding=7)
        window.configure(background='#141c2c')
        frame = ttk.Frame(window, padding=20)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text='J A R V I S  /  INVOKER', font=('Segoe UI', 22, 'bold')).pack(anchor='w')
        ttk.Label(frame, text='Голос → три сферы → Invoke → применение на курсор').pack(anchor='w', pady=(3, 10))
        self.status = tk.StringVar(value='Пауза · загрузите микрофон')
        ttk.Label(frame, textvariable=self.status, font=('Segoe UI', 12, 'bold')).pack(anchor='w', pady=5)
        controls = ttk.Frame(frame)
        controls.pack(fill='x', pady=8)
        self.load_button = ttk.Button(controls, text='Загрузить микрофон', command=self.start)
        self.load_button.pack(side='left')
        ttk.Button(controls, text='F8 · Старт / пауза', command=self.toggle).pack(side='left', padx=8)
        ttk.Label(controls, text='F9 · Выход').pack(side='left')
        ttk.Button(controls, text='Подключить Dota (GSI)', command=self.setup_gsi).pack(side='right')
        self.gsi_status = tk.StringVar(value='GSI: ожидание данных Dota 2')
        ttk.Label(frame, textvariable=self.gsi_status, wraplength=780).pack(anchor='w', pady=(0, 7))

        settings = ttk.Frame(frame)
        settings.pack(fill='x')
        self.keyvars = {}
        for column, (role, label) in enumerate((('q', 'Quas'), ('w', 'Wex'), ('e', 'Exort'), ('invoke', 'Invoke'), ('cast', 'Первый слот'))):
            ttk.Label(settings, text=label).grid(row=0, column=column, padx=6, sticky='w')
            var = tk.StringVar(value=self.config['keys'][role])
            self.keyvars[role] = var
            ttk.Entry(settings, textvariable=var, width=12).grid(row=1, column=column, padx=6, pady=4)
        self.gap = tk.StringVar(value=str(self.config['key_gap_ms']))
        self.delay = tk.StringVar(value=str(self.config['invoke_wait_ms']))
        ttk.Label(settings, text='Между клавишами, мс').grid(row=2, column=0, columnspan=2, sticky='w', pady=5)
        ttk.Entry(settings, textvariable=self.gap, width=10).grid(row=2, column=2)
        ttk.Label(settings, text='После Invoke, мс').grid(row=3, column=0, columnspan=2, sticky='w')
        ttk.Entry(settings, textvariable=self.delay, width=10).grid(row=3, column=2)
        self.dry = tk.BooleanVar(value=self.config['dry_run'])
        self.wake = tk.BooleanVar(value=self.config['require_jarvis'])
        ttk.Checkbutton(frame, text='Проверка голоса без нажатий (работает и вне Dota)', variable=self.dry).pack(anchor='w', pady=(8, 3))
        ttk.Checkbutton(frame, text='Принимать только фразы «Джарвис, название»', variable=self.wake).pack(anchor='w')
        microw = ttk.Frame(frame)
        microw.pack(fill='x', pady=8)
        ttk.Label(microw, text='Микрофон:').pack(side='left')
        self.device = tk.StringVar()
        self.devices = ttk.Combobox(microw, textvariable=self.device, state='readonly', width=45)
        self.devices.pack(side='left', padx=8)
        self.device_ids = {'По умолчанию Windows': None}
        try:
            import sounddevice as sd
            for index, info in enumerate(sd.query_devices()):
                if info['max_input_channels'] > 0:
                    self.device_ids[f'{index}: {info["name"]}'] = index
        except Exception as error:
            self.events.put(('log', f'Микрофоны: {error}'))
        self.devices['values'] = list(self.device_ids)
        self.device.set(next((name for name, index in self.device_ids.items() if index == self.config['device']), 'По умолчанию Windows'))
        ttk.Button(microw, text='Сохранить', command=self.save).pack(side='left')
        ttk.Label(frame, text='Изменения применяются после сохранения. Микрофон и словарь перезапускаются.').pack(anchor='w')

        table = ttk.Treeview(frame, columns=('name', 'voice', 'orbs'), show='headings', height=10)
        for key, title, width in (('name', 'Заклинание', 185), ('voice', 'Скажи', 390), ('orbs', 'Сферы', 75)):
            table.heading(key, text=title)
            table.column(key, width=width)
        for spell in SPELLS:
            table.insert('', 'end', values=(spell.name, ' / '.join(spell.aliases[:3]), spell.orbs.upper()))
        table.pack(fill='x', pady=10)
        ttk.Label(frame, text='Quickcast для первого слота, Legacy Keys выключены. Перед чатом нажмите F8.\nInvoke проверяется через GSI; без подтверждения нужного заклинания D не нажимается.').pack(anchor='w')
        self.logbox = tk.Text(frame, height=6, bg='#0c1320', fg='#b8d8ee', wrap='word', state='disabled', font=('Consolas', 10))
        self.logbox.pack(fill='both', expand=True, pady=(8, 0))
        self.log('Говорите одно название за раз; после фразы сделайте короткую паузу.')
        self.start_gsi()
        window.protocol('WM_DELETE_WINDOW', self.close)
        window.after(30, self.poll)

    def start_gsi(self):
        if self.gsi_server is not None:
            return
        try:
            self.gsi_token = load_token(ROOT)
            self.gsi_server = Server(self.gsi, self.gsi_token)
            self.log('GSI: приём данных на 127.0.0.1:37219. Подключите Dota один раз.')
        except (OSError, ValueError) as error:
            self.log(f'GSI не запущен: {error}. Реальные команды будут заблокированы.')

    def setup_gsi(self):
        self.pause()
        self.start_gsi()
        if self.gsi_server is None:
            messagebox.showerror('GSI', 'Не удалось запустить GSI. Проверьте журнал и закройте вторую копию помощника.')
            return
        directory = filedialog.askdirectory(title='Выберите папку Dota 2 (обычно «dota 2 beta»)')
        if not directory:
            return
        try:
            target = install_config(directory, self.gsi_token)
            self.log(f'GSI: создан {target}')
            messagebox.showinfo('Подключение Dota', 'Файл GSI установлен.\n\nВ Steam → Dota 2 → Свойства → Общие → Параметры запуска\nдобавьте -gamestateintegration, сохранив остальные параметры.\n\nПерезапустите Dota и откройте демонстрацию Инвокера.\nВ строке GSI должна появиться готовность или перезарядка Invoke.')
        except (ValueError, OSError) as error:
            messagebox.showerror('GSI', str(error))

    def log(self, text):
        self.logbox.configure(state='normal')
        self.logbox.insert('end', time.strftime('%H:%M:%S ') + text + '\n')
        if int(self.logbox.index('end-1c').split('.')[0]) > 250:
            self.logbox.delete('1.0', '50.0')
        self.logbox.see('end')
        self.logbox.configure(state='disabled')

    def pause(self):
        with self.lock:
            self.armed = False
            self.epoch += 1
            self.listening = False
            self.discard_before = time.monotonic()

    def toggle(self):
        if not self.ready:
            self.log('Сначала нажмите «Загрузить микрофон» и дождитесь готовности.')
            return
        with self.lock:
            self.armed = not self.armed
            self.epoch += 1
            self.discard_before = time.monotonic()
        self.log('Слушаю команды.' if self.armed else 'Пауза.')

    def save(self):
        self.pause()
        try:
            config = copy.deepcopy(self.config)
            config.update(keys={k: v.get().strip().lower() for k, v in self.keyvars.items()},
                          key_gap_ms=int(self.gap.get()), invoke_wait_ms=int(self.delay.get()),
                          dry_run=self.dry.get(), require_jarvis=self.wake.get(), device=self.device_ids[self.device.get()])
            validate(config)
            temporary = ROOT / 'config.json.tmp'
            temporary.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf-8')
            temporary.replace(ROOT / 'config.json')
            self.config = config
            if self.worker and self.worker.is_alive():
                self.worker_stop.set()
            self.ready = False
            self.log('Сохранено. Нажмите «Загрузить микрофон», затем F8.')
        except (ValueError, KeyError, OSError) as error:
            messagebox.showerror('Настройки', str(error))

    def start(self):
        if self.worker and self.worker.is_alive():
            self.log('Микрофон уже запущен или останавливается. Для новых настроек сохраните и повторите через секунду.')
            return
        self.pause()
        self.ready = False
        self.worker_stop = threading.Event()
        self.worker = threading.Thread(target=self.listen, args=(copy.deepcopy(self.config), self.worker_stop), daemon=True)
        self.worker.start()
        self.log('Загрузка модели и микрофона…')

    def allowed(self, epoch, config):
        with self.lock:
            valid = self.armed and self.epoch == epoch and not self.shutdown.is_set()
        return valid and (config['dry_run'] or (self.keyboard.dota_focused() and not self.keyboard.modifiers_held()))

    def listen(self, config, stop):
        try:
            import sounddevice as sd
            from vosk import Model, KaldiRecognizer, SetLogLevel
            path = ROOT / 'model'
            if not (path / 'am' / 'final.mdl').exists():
                raise RuntimeError('Нет модели. Запустите install.bat с интернетом.')
            SetLogLevel(-1)
            model = Model(str(path))
            rate = int(sd.query_devices(config['device'], 'input')['default_samplerate'])
            recognizer = KaldiRecognizer(model, rate, json.dumps(vocabulary(config['require_jarvis']), ensure_ascii=False))
            recognizer.SetWords(True)
            def callback(data, frames, timing, status):
                now = time.monotonic()
                with self.lock:
                    if not self.listening:
                        return
                    epoch = self.epoch
                if status:
                    # Drop discontinuous audio and invalidate the partial utterance.
                    with self.lock:
                        self.epoch += 1
                    return
                try:
                    self.audio.put_nowait((now, epoch, bytes(data)))
                except queue.Full:
                    with self.lock:
                        self.epoch += 1

            with sd.RawInputStream(device=config['device'], samplerate=rate, blocksize=int(rate * 0.05),
                                   dtype='int16', channels=1, callback=callback):
                self.events.put(('ready', True))
                last_epoch = -1
                while not stop.is_set() and not self.shutdown.is_set():
                    try:
                        captured, epoch, data = self.audio.get(timeout=0.15)
                    except queue.Empty:
                        continue
                    if epoch != last_epoch:
                        recognizer.Reset()
                        last_epoch = epoch
                    if captured < self.discard_before or time.monotonic() - captured > 0.6 or not self.allowed(epoch, config):
                        recognizer.Reset()
                        continue
                    if not recognizer.AcceptWaveform(data):
                        continue
                    result = json.loads(recognizer.Result())
                    text = result.get('text', '')
                    if not text:
                        continue
                    spell = recognize(text, config['require_jarvis'])
                    confidence = min((word.get('conf', 0) for word in result.get('result', [])), default=0)
                    if not spell or confidence < config['minimum_confidence']:
                        self.events.put(('log', f'Не принято: {text}'))
                        continue
                    if not self.allowed(epoch, config):
                        continue
                    with self.lock:
                        self.listening = False
                    keys = ' → '.join(sequence(spell, config)).upper()
                    if config['dry_run']:
                        self.events.put(('log', f'ПРОВЕРКА: {spell.name}: {keys}'))
                    else:
                        guard = CastGuard(self.gsi, spell)
                        done = execute(spell, config, self.keyboard, lambda: self.allowed(epoch, config), guard=guard)
                        self.events.put(('log', f'{spell.name}: {keys}' if done else
                                         (guard.error or 'Команда отменена: пауза, модификатор или смена окна.')))
                    self.discard_before = time.monotonic()
                    recognizer.Reset()
        except Exception as error:
            self.events.put(('log', f'Ошибка: {error}'))
        finally:
            self.events.put(('ready', False))

    def poll(self):
        for vk in (0x77, 0x78):  # F8/F9, rising edge only.
            held = self.keyboard.held(vk)
            if held and not self.previous_hotkeys.get(vk, False):
                if vk == 0x78:
                    self.close()
                    return
                self.toggle()
            self.previous_hotkeys[vk] = held
        for _ in range(50):
            try:
                kind, value = self.events.get_nowait()
            except queue.Empty:
                break
            if kind == 'log':
                self.log(value)
            else:
                self.ready = value
                self.pause()
                self.log('Микрофон готов. F8 — начать.' if value else 'Микрофон остановлен.')
        active = self.ready and self.armed
        focused = self.config['dry_run'] or self.keyboard.dota_focused()
        accept = active and focused and (self.config['dry_run'] or not self.keyboard.modifiers_held())
        with self.lock:
            if self.listening and not accept:
                self.epoch += 1
                self.discard_before = time.monotonic()
            self.listening = accept
        self.status.set('ПРОВЕРКА · слушаю, клавиши отключены' if active and self.config['dry_run'] else
                        'СЛУШАЮ · Dota 2' if accept else
                        'Ожидание активного окна Dota 2 / отпускания модификаторов' if active else 'ПАУЗА · F8 для старта')
        self.gsi_status.set('GSI: ' + (self.gsi.invoke_error() or 'Invoke готов'))
        self.window.after(30, self.poll)

    def close(self):
        self.pause()
        self.shutdown.set()
        # Keep process alive briefly so an in-flight key gets its key-up.
        self.finish_close()

    def finish_close(self):
        if self.worker and self.worker.is_alive():
            self.window.after(50, self.finish_close)
        else:
            if self.gsi_server is not None:
                self.gsi_server.close()
                self.gsi_server = None
            self.window.destroy()


if __name__ == '__main__':
    root = tk.Tk()
    try:
        App(root)
        root.mainloop()
    except Exception as error:
        messagebox.showerror('JARVIS', str(error))
        root.destroy()
