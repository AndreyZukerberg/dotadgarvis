"""Windows SendInput, scan codes and foreground-process verification."""
import ctypes as C
from ctypes import wintypes as W
from pathlib import PureWindowsPath
import sys


class WindowsInput:
    def __init__(self):
        if sys.platform != 'win32':
            raise RuntimeError('Отправка клавиш поддерживается только в Windows.')
        self.user = C.WinDLL('user32', use_last_error=True)
        self.kernel = C.WinDLL('kernel32', use_last_error=True)
        ptr = C.c_size_t

        class KEYBDINPUT(C.Structure):
            _fields_ = [('wVk', W.WORD), ('wScan', W.WORD), ('dwFlags', W.DWORD),
                        ('time', W.DWORD), ('dwExtraInfo', ptr)]

        class MOUSEINPUT(C.Structure):
            _fields_ = [('dx', W.LONG), ('dy', W.LONG), ('mouseData', W.DWORD),
                        ('dwFlags', W.DWORD), ('time', W.DWORD), ('dwExtraInfo', ptr)]

        class HARDWAREINPUT(C.Structure):
            _fields_ = [('uMsg', W.DWORD), ('wParamL', W.WORD), ('wParamH', W.WORD)]

        class UNION(C.Union):
            _fields_ = [('ki', KEYBDINPUT), ('mi', MOUSEINPUT), ('hi', HARDWAREINPUT)]

        class INPUT(C.Structure):
            _anonymous_ = ('value',)
            _fields_ = [('type', W.DWORD), ('value', UNION)]

        self.INPUT, self.KEYBDINPUT = INPUT, KEYBDINPUT
        signatures = [
            (self.user.SendInput, [W.UINT, C.POINTER(INPUT), C.c_int], W.UINT),
            (self.user.GetForegroundWindow, [], W.HWND),
            (self.user.GetWindowThreadProcessId, [W.HWND, C.POINTER(W.DWORD)], W.DWORD),
            (self.user.GetAsyncKeyState, [C.c_int], W.SHORT),
            (self.user.MapVirtualKeyW, [W.UINT, W.UINT], W.UINT),
            (self.kernel.OpenProcess, [W.DWORD, W.BOOL, W.DWORD], W.HANDLE),
            (self.kernel.QueryFullProcessImageNameW, [W.HANDLE, W.DWORD, W.LPWSTR, C.POINTER(W.DWORD)], W.BOOL),
            (self.kernel.CloseHandle, [W.HANDLE], W.BOOL),
        ]
        for fn, args, result in signatures:
            fn.argtypes, fn.restype = args, result

    def held(self, vk):
        return bool(self.user.GetAsyncKeyState(vk) & 0x8000)

    def modifiers_held(self):
        return any(self.held(v) for v in (0x10, 0x11, 0x12, 0x5B, 0x5C))

    def dota_focused(self):
        hwnd = self.user.GetForegroundWindow()
        pid = W.DWORD()
        self.user.GetWindowThreadProcessId(hwnd, C.byref(pid))
        handle = self.kernel.OpenProcess(0x1000, False, pid.value)
        if not handle:
            return False
        try:
            length = W.DWORD(32768)
            path = C.create_unicode_buffer(length.value)
            return bool(self.kernel.QueryFullProcessImageNameW(handle, 0, path, C.byref(length))) and PureWindowsPath(path.value).name.lower() == 'dota2.exe'
        finally:
            self.kernel.CloseHandle(handle)

    def send(self, key, released):
        scan = self.user.MapVirtualKeyW(ord(key.upper()), 0)
        if not scan:
            raise RuntimeError(f'Не найден скан-код клавиши {key}.')
        item = self.INPUT(type=1, ki=self.KEYBDINPUT(0, scan, 0x0008 | (0x0002 if released else 0), 0, 0))
        if self.user.SendInput(1, C.byref(item), C.sizeof(item)) != 1:
            raise C.WinError(C.get_last_error())

    def down(self, key):
        self.send(key, False)

    def up(self, key):
        self.send(key, True)
